#ifndef TYPES_H
#define TYPES_H

#include <QtGui>

#ifndef MAX_PATH
#define MAX_PATH 512
#endif

static QString VerProg = "1.0.0.1";

// types of programm

#define _CLIENT_FILE_STATUS_LOST	-1;
#define _CLIENT_FILE_STATUS_CHANGE	1;
#define _CLIENT_FILE_STATUS_OK		0;


struct FileInfoStruct
{
    int Type;
    QString FileName;
    long int size;
    QString FileHash;
    QString FileDate;
    QString FileTime;
    QString FileDateTime;
    QString FileAllStr;
    int Flag;
};

#endif // TYPES_H
