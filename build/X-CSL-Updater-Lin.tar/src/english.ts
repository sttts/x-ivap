<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US" sourcelanguage="ru_RU">
<context>
    <name>About</name>
    <message utf8="true">
        <location filename="about.ui" line="35"/>
        <source>X-CSL-Updater :: О программе</source>
        <translation>X-CSL-Updater :: About</translation>
    </message>
    <message utf8="true">
        <location filename="about.ui" line="98"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Больше информации по ссылке &lt;a href=&quot;http://www.x-air.ru&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.x-air.ru&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;more info at &lt;a href=&quot;http://www.x-air.ru&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.x-air.ru&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="about.ui" line="105"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Больше информации по ссылке &lt;/span&gt;&lt;a href=&quot;http://www.x-air.ru&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;www.x-air.ru&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;more info at&lt;/span&gt;&lt;a href=&quot;http://www.x-air.ru&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;www.x-air.ru&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="about.ui" line="134"/>
        <source>X-CSL-Updater ver.: </source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="about.ui" line="158"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Copyright © 2009 &lt;/span&gt;&lt;a href=&quot;http:steptosky.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;StepToSky (&lt;/span&gt;&lt;/a&gt;&lt;a href=&quot;http://steptosky.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://steptosky.com&lt;/span&gt;&lt;/a&gt;&lt;a href=&quot;http:steptosky.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;)&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;&amp;amp;&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Copyright © 2009 &lt;/span&gt;&lt;a href=&quot;http://team.x-air.ru&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;X-AiR Team (http://team.x-air.ru)&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;***&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Programming - den_rain (&lt;/span&gt;&lt;a href=&quot;den_rain@steptosky.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;den_rain@steptosky.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;***&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;build win32/64 - den_rain  (&lt;/span&gt;&lt;a href=&quot;den_rain@steptosky.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;den_rain@steptosky.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;build Linux - Saturn  (&lt;/span&gt;&lt;a href=&quot;mailto://frizins@gmail.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;frizins@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;build MacOS - TheChoix  (&lt;/span&gt;&lt;a href=&quot;mailto://choixer@gmail.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;choixer@gmail.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;***&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Official site of project X-CSL-Package (&lt;/span&gt;&lt;a href=&quot;http://csl.x-air.ru&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://csl.x-air.ru&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;).&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="about.ui" line="62"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Больше информации по ссылке &lt;a href=&quot;http://www.steptosky.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.steptosky.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;more info at&lt;a href=&quot;http://www.steptosky.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;www.steptosky.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="about.ui" line="69"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Больше информации по ссылке &lt;/span&gt;&lt;a href=&quot;http://www.steptosky.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;www.steptosky.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;more info at&lt;/span&gt;&lt;a href=&quot;http://www.steptosky.com&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;www.steptosky.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>Index</name>
    <message>
        <source>Èíäåêñàöèÿ:</source>
        <translation type="obsolete">Start Index:</translation>
    </message>
    <message>
        <location filename="index.cpp" line="34"/>
        <location filename="index.cpp" line="77"/>
        <location filename="index.cpp" line="168"/>
        <source>x-csl-indexes.idx</source>
        <translation></translation>
    </message>
    <message>
        <location filename="index.cpp" line="51"/>
        <source>Èíäåêñàöèÿ çàâåðøåíà!</source>
        <translation>End of Index!</translation>
    </message>
    <message>
        <source>Äëÿ ïîëíîãî îáíîâëåíèÿ âàì íåîáõîäèìî çàãðóçèòü %1 èç %2 áàéò.</source>
        <translation type="obsolete">For full Update your must download %1 of %2 bytes.</translation>
    </message>
    <message>
        <source>Âûäåëèòå íåîáõîäèìûå CSL-Package ìîäåëè â ñïèñêå è íàæìèòå &quot;Óñòàíîâêà/Îáíîâëåíèå&quot;.</source>
        <translation type="obsolete">Select necessary items from List and press &quot;Install/Update&quot;.</translation>
    </message>
    <message>
        <source>Ó âàñ èìååòñÿ ïîëíàÿ ïîñëåäíÿÿ âåðñèÿ X-CSL-Package, Ïîçäðàâëÿåì!</source>
        <translation type="obsolete">Congratulations! You have full package of X-CSL-Package!</translation>
    </message>
    <message>
        <location filename="index.cpp" line="68"/>
        <source>Íåâîçìîæíî âûïîëíèòü èíäåêñàöèþ!</source>
        <translation>Unable to Index!</translation>
    </message>
    <message>
        <location filename="index.cpp" line="81"/>
        <location filename="index.cpp" line="172"/>
        <location filename="index.cpp" line="278"/>
        <source>Îøèáêà: %1</source>
        <translation>Error: %1</translation>
    </message>
    <message>
        <source>Èíäåêñèðóåì CSL ìîäåëè...</source>
        <translation type="obsolete">Index for CSL Model...</translation>
    </message>
    <message>
        <source>Ïîäîæäèòå</source>
        <translation type="obsolete">Please Wait</translation>
    </message>
    <message>
        <source>Not</source>
        <translation type="obsolete">Please wait</translation>
    </message>
    <message>
        <location filename="index.cpp" line="121"/>
        <source>%3 (%4)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="index.cpp" line="135"/>
        <source>Óñòàíîâëåíî</source>
        <translation>It Is Installed</translation>
    </message>
    <message>
        <source>Òðåáóåò Îáíîâëåíèÿ</source>
        <translation type="obsolete">Needs for Update</translation>
    </message>
    <message>
        <location filename="index.cpp" line="149"/>
        <source>Íå óñòàíîâëåíî</source>
        <translation></translation>
    </message>
    <message>
        <location filename="index.cpp" line="153"/>
        <source>Íå âûÿñíåíî</source>
        <translation></translation>
    </message>
    <message>
        <source>Îøèáêà: Íå ìîãó çàïèñàòü ôàéë íà âàø êîìïüþòåð -  %1: %2.</source>
        <translation type="obsolete">Error: Unable create file on your computer - %1: %2.</translation>
    </message>
    <message>
        <location filename="index.cpp" line="26"/>
        <source>Èíäåêñèðîâàíèå:</source>
        <translation>Indexing:</translation>
    </message>
    <message>
        <location filename="index.cpp" line="55"/>
        <source>Äëÿ ïîëíîãî îáíîâëåíèÿ âàì íåîáõîäèìî çàãðóçèòü %1 MB èç %2 MB</source>
        <translation>For full Update you need download %1 of %2 MB</translation>
    </message>
    <message>
        <location filename="index.cpp" line="56"/>
        <source>Âûäåëèòå íåîáõîäèìûå ïàêåòû X-CSL ìîäåëåé â ñïèñêå è íàæìèòå &quot;Îáíîâèòü&quot;.</source>
        <translation>Select the necessary X-CSL packages in list and press &quot;Update&quot;.</translation>
    </message>
    <message>
        <location filename="index.cpp" line="60"/>
        <source>Ïîçäðàâëÿåì!, Ó âàñ èìååòñÿ ïîëíàÿ ïîñëåäíÿÿ âåðñèÿ ïàêåòîâ X-CSL ìîäåëåé.</source>
        <translation>Congratulation!, You have full last version of X-CSL packages.</translation>
    </message>
    <message>
        <location filename="index.cpp" line="87"/>
        <source>Îøèáêà: Èíäåêñíûé ôàéë èìååò íóëåâîé ðàçìåð! %1</source>
        <translation>Error: Index file have NULL size %1</translation>
    </message>
    <message>
        <location filename="index.cpp" line="105"/>
        <source>Îøèáêà: Èíäåêñíûé ôàéë èìååò íå âåðíûé ôîðìàò!</source>
        <translation>Error: Index file have Wrong format!</translation>
    </message>
    <message>
        <location filename="index.cpp" line="120"/>
        <source>Ïîäîæäèòå...</source>
        <translation>Please Wait...</translation>
    </message>
    <message>
        <location filename="index.cpp" line="142"/>
        <source>Òðåáóåò îáíîâëåíèÿ</source>
        <translation>Need Update</translation>
    </message>
    <message>
        <location filename="index.cpp" line="247"/>
        <source>Îøèáêà: Íå ìîãó çàïèñàòü ôàéë íà âàø êîìïüþòåð - %1 : %2.</source>
        <translation>Error: I can&apos;t write file on your computer - %1 : %2.</translation>
    </message>
    <message>
        <location filename="index.cpp" line="259"/>
        <source>Ñêà÷èâàåì èíäåêñíûé ôàéë ñ ñåðâåðà &quot;%1&quot; ...</source>
        <translation>Downloading index file from server : %1...</translation>
    </message>
    <message>
        <location filename="index.cpp" line="282"/>
        <source>OK!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="index.cpp" line="310"/>
        <source>Îøèáêà : %1.</source>
        <translation>Error: %1.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.cpp" line="20"/>
        <source>C:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="20"/>
        <source>X-Plane</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="20"/>
        <source>plugins</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="20"/>
        <source>X-IvAp Resources</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="20"/>
        <source>CSL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="20"/>
        <source>Resources</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="24"/>
        <source>Î÷èñòèòü</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="26"/>
        <location filename="mainwindow.cpp" line="31"/>
        <source>Âûäåëèòü Âñå</source>
        <translation>Select All</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="34"/>
        <source>Èíôîðìàöèÿ</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="49"/>
        <source>X-CSL-Updater, Ver.:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="55"/>
        <source>Óêàæèòå ïóòü ê ôàéëó X-Plane.exe è íàæìèòå &quot;Èíäåêñèðîâàòü&quot;</source>
        <translation>Select the X-Plane.exe file and press &quot;Index&quot;</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="56"/>
        <source>äëÿ èíäåêñèðîâàíèÿ è îïðåäåëåíèÿ ôàéëîâ, íóæäàþùèõñÿ â îáíîâëåíèè.</source>
        <translation>for indexing and determinations of the files, needing for updating.</translation>
    </message>
    <message>
        <source>Âûáåðèòå íåîáõîäèìûé &quot;Ïóòü Óñòàíîâêè&quot; è íàæìèòå &quot;Èíäåêñàöèÿ&quot; äëÿ èíäåêñèðîâàíèÿ âàøèõ ôàéëîâ.</source>
        <translation type="obsolete">Press Index for Indexes your files.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="171"/>
        <source>Óêàæèòå ïóòü ê ôàéëó X-Plane.exe</source>
        <translation>Select the Path to file X-Plane.exe</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="171"/>
        <source>X-Plane.exe (X-Plane.exe)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="176"/>
        <source>Resources/plugins/X-IvAp Resources/CSL</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="187"/>
        <source>Îøèáêà: Â âûáðàííîé âåðñèè X-Plane íå óñòàíîâëåí ïëàãèí X-IvAp!</source>
        <translation>In selected versions of X-Plane is not installed plugin X-IvAp!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="196"/>
        <source>Âíèìàíèå! Äàííàÿ ôóíêöèÿ ïðåäíàçíà÷åíà äëÿ ïðîôåññèîíàëüíîãî èñïîëüçîâàíèÿ. Âîçìîæíî ïðîãðàììà ñòàíåò íåðàáîòîñïîñîáíîé!</source>
        <translation>Attention! Given function is intended for professional use. Possible, the program will become disabled!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="198"/>
        <source>X-CSL-Updater :: Âûáåðèòå ïàïêó X-Plane</source>
        <translation>Select install path</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="44"/>
        <source>X-CSL-Updater</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Информация:</source>
        <translation type="obsolete">Info and Log:</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="129"/>
        <source>Путь Установки:</source>
        <translation>Path for Install:</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="145"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Лог работы программы...</source>
        <translation type="obsolete">Log...</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="192"/>
        <source>Вы можете очистить лог, выбрав в контекстном меню пункт &quot;Очистить&quot;</source>
        <translation>You can clear log. Check &quot;ContextMenu&quot;</translation>
    </message>
    <message utf8="true">
        <source>Прогресс Бар - показывает ход работы</source>
        <translation type="obsolete">Progres Bar</translation>
    </message>
    <message utf8="true">
        <source>Список:</source>
        <translation type="obsolete">List:</translation>
    </message>
    <message utf8="true">
        <source>Список X-CSL-Package, в нем вы можете выбрать интересующие модели и нажать &quot;Установка/Обновление&quot;</source>
        <translation type="obsolete">List of X-CSL-Packsge</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="311"/>
        <source>#ID</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="316"/>
        <source>Название</source>
        <translation>Title</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="321"/>
        <source>Инфо</source>
        <translation>Info</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="326"/>
        <source>Версия</source>
        <translation>Version</translation>
    </message>
    <message utf8="true">
        <source>Размер</source>
        <translation type="obsolete">Size</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="331"/>
        <source>Размер (MB)</source>
        <translation>Size of MB</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="336"/>
        <source>Статус</source>
        <translation>Status</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="341"/>
        <source>Код</source>
        <translation>Code</translation>
    </message>
    <message utf8="true">
        <source>Выделить все в списке</source>
        <translation type="obsolete">Select all in List</translation>
    </message>
    <message utf8="true">
        <source>Выделить Все!</source>
        <translation type="obsolete">Select All!</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="27"/>
        <location filename="mainwindow.cpp" line="32"/>
        <source>Ctrl+A</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Нажмите для индексации ваших файлов</source>
        <translation type="obsolete">Press Index for Indexes your files</translation>
    </message>
    <message utf8="true">
        <source>Индексация</source>
        <translation type="obsolete">Index</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="409"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Нажмите для обновления</source>
        <translation type="obsolete">Press for Update</translation>
    </message>
    <message utf8="true">
        <source>Установка/Обновление</source>
        <translation type="obsolete">Install/Update</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="432"/>
        <source>Ctrl+U</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="81"/>
        <source>logo</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="158"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Выбрать путь для установки пакетов &lt;span style=&quot; font-weight:600;&quot;&gt;X-CSL&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Select path for install&lt;span style=&quot; font-weight:600;&quot;&gt;X-CSL Package&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="165"/>
        <source>Обзор</source>
        <translation>Browse</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="185"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Лог работы программы&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Log of working program&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="237"/>
        <source>Список пакетов X-CSL, доступных на сервере:</source>
        <translation>List of  X-CSL-Packages, available on server:</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="258"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Выделите необходимые пакеты &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;X-CSL&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; и нажмите Обновить&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Select necessary&lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;X-CSL-Packages&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;and press &quot;Update&quot;&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="357"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Выделить пакеты &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;X-CSL&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; в списке (Ctrl+A)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Select All &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;X-CSL-Packages&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;in list (Ctrl+A)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="364"/>
        <source>Выделить Все</source>
        <translation>Select All</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="387"/>
        <source>Прервать текущее действие</source>
        <translation>Cancel current action</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="390"/>
        <source>Отменить</source>
        <translation>Cancel</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="403"/>
        <source>Индексация ваших файлов (Ctrl+I)</source>
        <translation>Indexing of your files (Ctrl+I)</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="406"/>
        <source>Индексировать</source>
        <translation>Index</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="422"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Запустить обновление выделенных пакетов &lt;span style=&quot; font-weight:600;&quot;&gt;X-CSL&lt;/span&gt; (Ctrl+U)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Start Update &lt;span style=&quot; font-weight:600;&quot;&gt;X-CSL-Packages &lt;/span&gt; (Ctrl+U)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="429"/>
        <source>Обновить</source>
        <translation>Update</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="454"/>
        <source>Файл</source>
        <translation>File</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="467"/>
        <source>Помощь</source>
        <translation>Help</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="477"/>
        <location filename="mainwindow.ui" line="480"/>
        <source>Путь Установки</source>
        <translation>Set Install Path</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="483"/>
        <location filename="mainwindow.ui" line="486"/>
        <source>Выберите путь для установки X-CSL-Package</source>
        <translation>Select Install Path</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="489"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="497"/>
        <source>Настройки</source>
        <translation>Settings</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="500"/>
        <location filename="mainwindow.ui" line="503"/>
        <source>Настройки программы</source>
        <translation>Settings of Programm</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="508"/>
        <source>Exit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="511"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="516"/>
        <source>О программе</source>
        <translation>About it</translation>
    </message>
    <message utf8="true">
        <location filename="mainwindow.ui" line="519"/>
        <location filename="mainwindow.ui" line="522"/>
        <source>Информация об этой программе...</source>
        <translation>About of this programm...</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="525"/>
        <source>Ctrl+/</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="530"/>
        <source>About Qt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="535"/>
        <source>Set Custom Path</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="538"/>
        <source>Ctrl+Shift+O</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="settings.cpp" line="36"/>
        <location filename="settings.cpp" line="45"/>
        <location filename="settings.cpp" line="49"/>
        <location filename="settings.cpp" line="53"/>
        <location filename="settings.cpp" line="57"/>
        <location filename="settings.cpp" line="61"/>
        <location filename="settings.cpp" line="103"/>
        <source>http://csl.x-air.ru/package/</source>
        <oldsource>http://x-air.ru/X-CSL-Package/CSL/</oldsource>
        <translation></translation>
    </message>
    <message>
        <location filename="settings.cpp" line="64"/>
        <location filename="settings.cpp" line="99"/>
        <source>x-csl-indexes.idx</source>
        <translation></translation>
    </message>
    <message>
        <location filename="settings.ui" line="29"/>
        <source>X-CSL-Updater :: Settings</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="47"/>
        <source>Сервер</source>
        <oldsource>Настройки</oldsource>
        <translation>Server</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="62"/>
        <source>Сервер 1:</source>
        <translation>Server1:</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="79"/>
        <location filename="settings.ui" line="113"/>
        <location filename="settings.ui" line="147"/>
        <location filename="settings.ui" line="181"/>
        <source>Выделенный галочкой сервер, будет использоватся программой</source>
        <translation>Programm will use  selected server</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="82"/>
        <location filename="settings.ui" line="116"/>
        <location filename="settings.ui" line="150"/>
        <location filename="settings.ui" line="184"/>
        <source>Используется</source>
        <translation>Used this Server</translation>
    </message>
    <message>
        <location filename="settings.ui" line="85"/>
        <location filename="settings.ui" line="119"/>
        <location filename="settings.ui" line="153"/>
        <location filename="settings.ui" line="187"/>
        <source>CheckGroup</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="92"/>
        <source>Сервер 2:</source>
        <translation>Server2:</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="99"/>
        <source>Адрес сервера #2</source>
        <translation>Addres of server</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="102"/>
        <location filename="settings.ui" line="136"/>
        <location filename="settings.ui" line="170"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Введите адрес сервера Установки /Обновления X-CSL-Package...&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Enter adress of server...&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="222"/>
        <source>Русский</source>
        <translation>Russian</translation>
    </message>
    <message utf8="true">
        <source>Введите адрес сервера для Установки /Обновления X-CSL-Package...</source>
        <translation type="obsolete">Will Enter the address of the server...</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="126"/>
        <source>Сервер 3:</source>
        <translation>Server3:</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="133"/>
        <source>Адрес сервера #3</source>
        <translation>Addres of server</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="160"/>
        <source>Сервер 4:</source>
        <translation>Server4:</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="167"/>
        <source>Адрес сервера #4</source>
        <translation>Addres of server</translation>
    </message>
    <message utf8="true">
        <source>Имя индексного файла:</source>
        <translation type="obsolete">Name of index file:</translation>
    </message>
    <message utf8="true">
        <source>Имя индексного файла</source>
        <translation type="obsolete">Name of index file</translation>
    </message>
    <message utf8="true">
        <source>Введите имя индексного файла...</source>
        <translation type="obsolete">Enter name of index file...</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="207"/>
        <source>Языки</source>
        <translation>Language</translation>
    </message>
    <message utf8="true">
        <source>Русский - (По Умолчанию)</source>
        <translation type="obsolete">Russian - (Default)</translation>
    </message>
    <message>
        <location filename="settings.ui" line="225"/>
        <location filename="settings.ui" line="235"/>
        <source>LangGroup</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="232"/>
        <source>Английский</source>
        <translation>English</translation>
    </message>
    <message utf8="true">
        <source>Примечание:</source>
        <translation type="obsolete">Note:</translation>
    </message>
    <message utf8="true">
        <source>Если Английский язык заблокирован, это означает что в каталоге с программой
отсутствует файл перевода english.qm</source>
        <oldsource>Для включения языка НЕ по умолчанию вы должны иметь соответсвующий
 файл имя_языка.gm в каталоге с программой.</oldsource>
        <translation type="obsolete">If English CheckBox is disabled now,
this means that in directory with program is absent file english.qm</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="260"/>
        <source>Нажмите для отмены введеных изменений</source>
        <translation>Press for Cancel</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="263"/>
        <source>Отмена</source>
        <translation>Cancel</translation>
    </message>
    <message utf8="true">
        <location filename="settings.ui" line="270"/>
        <source>Нажмите для подтверждения введеных изменений</source>
        <translation>Press for Save Settings</translation>
    </message>
    <message>
        <location filename="settings.ui" line="273"/>
        <source>OK</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Update</name>
    <message>
        <location filename="update.cpp" line="60"/>
        <location filename="update.cpp" line="89"/>
        <location filename="update.cpp" line="107"/>
        <location filename="update.cpp" line="154"/>
        <location filename="update.cpp" line="182"/>
        <source>/</source>
        <translation></translation>
    </message>
    <message>
        <location filename="update.cpp" line="21"/>
        <source>Îïåðàöèÿ ïðåðâàíà ïîëüçîâàòåëåì! Ïîäîæäèòå...</source>
        <translation>Canceling by user! Wait...</translation>
    </message>
    <message>
        <location filename="update.cpp" line="71"/>
        <source>Îáíîâëåíèå çàâåðøåíî!</source>
        <translation>Updating is done!</translation>
    </message>
    <message>
        <location filename="update.cpp" line="101"/>
        <source>Îøèáêà: Íå ìîãó çàïèñàòü ôàéë íà âàø êîìïüþòåð - %1 : %2.</source>
        <translation>Error: I can&apos;t write file on your computer - %1 : %2.</translation>
    </message>
    <message>
        <location filename="update.cpp" line="122"/>
        <source>Îáíîâëÿåì: %1...</source>
        <translation>Updating: %1...</translation>
    </message>
    <message>
        <location filename="update.cpp" line="142"/>
        <source>Îøèáêà: %1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="update.cpp" line="146"/>
        <source>OK!</source>
        <translation></translation>
    </message>
    <message>
        <location filename="update.cpp" line="176"/>
        <source>Îøèáêà : %1.</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>info</name>
    <message>
        <location filename="info.cpp" line="61"/>
        <location filename="info.cpp" line="62"/>
        <source>/x-csl-info.info</source>
        <translation></translation>
    </message>
    <message>
        <location filename="info.cpp" line="62"/>
        <source>/</source>
        <translation></translation>
    </message>
    <message>
        <location filename="info.cpp" line="72"/>
        <location filename="info.cpp" line="73"/>
        <location filename="info.cpp" line="145"/>
        <location filename="info.cpp" line="146"/>
        <source>Èíôîðìàöèÿ îòñóòñòâóåò...</source>
        <translation>Information not available...</translation>
    </message>
    <message>
        <location filename="info.ui" line="29"/>
        <source>X-CSL-Updater :: Info</source>
        <translation></translation>
    </message>
    <message utf8="true">
        <source>Информация о выбранном X-CSL-Package:</source>
        <translation type="obsolete">Information on chosen by X-CSL-Package:</translation>
    </message>
    <message utf8="true">
        <source>Здесь отображается информация о выбраном X-CSL-Package...</source>
        <translation type="obsolete">Here information is displayed about chosen by X-CSL-Package...</translation>
    </message>
    <message utf8="true">
        <location filename="info.ui" line="37"/>
        <source>Информация о выбранном пакете &lt;strong&gt;X-CSL&lt;/strong&gt;:</source>
        <translation>Info about selected &lt;strong&gt;X-CSL-Package&lt;/strong&gt;:</translation>
    </message>
    <message utf8="true">
        <location filename="info.ui" line="50"/>
        <source>Информация о выбранном пакете X-CSL</source>
        <translation>Info about selected X-CSL-Package</translation>
    </message>
    <message utf8="true">
        <location filename="info.ui" line="53"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Из этого информационного окна вы можете узнать больше о выбранном пакете &lt;span style=&quot; font-weight:600;&quot;&gt;X-CSL&lt;/span&gt;.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Более подробно узнать о пакетах X-CSL для X-Plane можно узнать на сайте &lt;span style=&quot; font-weight:600;&quot;&gt;X-CSL Package&lt;/span&gt;.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;more info at &lt;span style=&quot; font-weight:600;&quot;&gt;X-CSL Package&lt;/span&gt; site (csl.x-air.ru).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="info.ui" line="87"/>
        <location filename="info.ui" line="90"/>
        <source>Нажмите для закрытия окна</source>
        <translation>Press for close window</translation>
    </message>
    <message>
        <location filename="info.ui" line="93"/>
        <source>OK</source>
        <translation></translation>
    </message>
</context>
</TS>
