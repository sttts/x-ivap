﻿X-CSL-Package©
http://csl.x-air.ru

Welcome to X-CSL Package!

What is this project and what is it created? First of all, this project is aimed at all users of flight simulator X-Plane, flying in the network IVAO®. As you know, to connect to IVAO uses X-IvAp client program. It includes a set of CSL-models, which is necessary for correct display aircrafts, helicopters, follow-me cars vehicles and another stuff of other users. That is, in other words, the library is the fact that you see around you (or in sight) of other members who joined the network in specific models of aircraft (helicopters), as well as to see these patterns in certain liveries (paint) of the different airlines. Users MSFS (FSX) in IVAO have client software service MTL, the main advantage of which is the centralization of these models of aircraft (helicopters) and the livery of many airlines. The user can download MTL-models which can then be run in the simulator. Unfortunately, such a service for X-Plane does not exist yet. But in the global plans of the implementation of this project is listed exactly similar tasks for the entire community of X-Plane users. In the meantime, our project will be implemented only part of these tasks.

Everyone who has ever confronted with the question of finding and installing CSL-models, know how non-standardized and dealt with individually appear on various portals and sites such packets (or individual objects) CSL-models, sometimes duplicating each other, which often leads to the impossibility of inoperability as simulator and the models themselves. Sometimes the quality of these models also leaves much to be desired. And we set the first task: to begin centrally collect CSL-model, test, upgrade (if necessary) and give each user the opportunity to have this kit, while not bothering to install and configure. The main criterion for selection - is the demand for specific models and performance of the entire set as a whole.

For these primary tasks has created a special program.

Please, read instructions for downloading and installation!

As it has been described on the home page - the aim of the project is organisation of centralised CSL-models package for each user. So for correct work of the package you should delete ALL files from \Resources\plugins\X-IvAp Resources\CSL folder of your simulator. If you are ONLY going to test our package - save a copy of current CSL folder somewhere aside.

Short instruction on how to start and use the software.

1. Download zip-archive (dmg-image for MacOS) according to your type of your operational system.
2. Unpack folder from archive into any place or mount the dmg image on MacOS.
3. To start the program:
 * for Windows-> Start X-CSL-Updater.exe;
 * for Linux-> Start X-CSL-Updater.
 * for Mac-> Copy X-CSL-Updater from dmg image to Applications folder and run
4. In the opened window press button "Browse" and specify an X-Plane executable file.
5. Press button "Index". During this moment will be executed is comparison of the CSL-models installed at your computer and existing on our server.
6. After indexation is completed, in the "Status" column opposite to each package of models it will be specified, whether the given package of updating demands or not.
7. For updating of packages, necessary to select a line corresponding to it (for select more one of lines - keep Ctrl-key or press "Select All" button) and then press button "Update".

Contact form on our web site -  http://csl.x-air.ru/contact
e-mаil: csl@x-air.ru, info@steptosky.com

Development:	X-AiR Team (http://x-air.ru)
Programming:	StepToSky (http://steptosky.com)